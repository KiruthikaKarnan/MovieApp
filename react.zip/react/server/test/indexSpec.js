var should = require("chai").should(),
// expect = require("chai").expect,
// assert = require("chai").assert,
supertest = require("supertest"),
app = require("../app");

var url = supertest("http://localhost:8080");


describe("Testing /movie/add Method", function(err){
 it("should respond", function(done){
   url
       .post("/movie/my")
       .expect(200)
       .end(function(err,res){
         res.text.should.be.equal("Movie added");
         done();
       });

 });
});

describe("Testing /movie/display Method ", function(err){
 it("should respond", function(done){
   url
       .get("/movie/fav")
       .expect(200)
       .expect('Content-Type', /json/)
       .end(function(err,res){
         var myObj = JSON.parse(res.text);
         myObj[0].Title.should.be.equal("P.S.I Love You");
         done();
       });

 });
});

describe("Testing /movie/update Method", function(err){
 it("should respond", function(done){
   url
       .put("/movie/update")
       .expect(200)
       .end(function(err,res){
         res.text.should.be.equal("Movie updated");
         done();
       });

 });
});

 describe("Testing /movie/delete Method ", function(err){
   it("should respond", function(done){
     url
         .delete("/movie/unfav")
         .expect(200)
         .end(function(err,res){
           res.text.should.be.equal("Movie deleted!");
           done();
         });
 });
   });
