var React= require('react');

var Home=React.createClass({

render: function(){
  return(
    <div>
    <br/><br/><br/><br/><br/><br/><br/><br/>
    <h1>This is Home Page.</h1>
    </div>
  );
}
});

module.exports=Home;
